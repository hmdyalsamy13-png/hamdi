package com.yawmiyat.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalLayoutDirection
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

private const val PREFS = "yawmiyat_local_v2"
private const val USERS = "users"
private const val RECORDS = "records"

data class User(val id:String,val name:String,val password:String,val role:String,val wage:Long)
data class WorkDay(val id:String,val workerId:String,val gregorian:String,val hijri:String,val weekday:String,val time:String,val status:String,val amount:Long,val notes:String)

class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{YawmiyatApp(applicationContext)}} }

class LocalStore(context:Context){
    private val prefs=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
    fun users():List<User>{val a=JSONArray(prefs.getString(USERS,"[]"));return (0 until a.length()).map{val o=a.getJSONObject(it);User(o.getString("id"),o.getString("name"),o.getString("password"),o.getString("role"),o.optLong("wage",0))}}
    fun addUser(u:User){val a=JSONArray(prefs.getString(USERS,"[]"));a.put(JSONObject().apply{put("id",u.id);put("name",u.name);put("password",u.password);put("role",u.role);put("wage",u.wage)});prefs.edit().putString(USERS,a.toString()).apply()}
    fun records():List<WorkDay>{val a=JSONArray(prefs.getString(RECORDS,"[]"));return (0 until a.length()).map{val o=a.getJSONObject(it);WorkDay(o.getString("id"),o.getString("workerId"),o.getString("gregorian"),o.getString("hijri"),o.getString("weekday"),o.getString("time"),o.getString("status"),o.optLong("amount",0),o.optString("notes"))}.reversed()}
    fun addRecord(r:WorkDay){val a=JSONArray(prefs.getString(RECORDS,"[]"));a.put(JSONObject().apply{put("id",r.id);put("workerId",r.workerId);put("gregorian",r.gregorian);put("hijri",r.hijri);put("weekday",r.weekday);put("time",r.time);put("status",r.status);put("amount",r.amount);put("notes",r.notes)});prefs.edit().putString(RECORDS,a.toString()).apply()}
}

@Composable fun YawmiyatApp(context:Context){
    val store=remember{LocalStore(context)};var current by remember{mutableStateOf<User?>(null)};var refresh by remember{mutableIntStateOf(0)}
    MaterialTheme{CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl){if(current==null)Login(store){current=it}else MainApp(store,current!!,{current=null},{refresh++},refresh)}}
}

@Composable fun Login(store:LocalStore,onLogin:(User)->Unit){
    var register by remember{mutableStateOf(false)};var name by remember{mutableStateOf("")};var pass by remember{mutableStateOf("")};var wage by remember{mutableStateOf("")};var role by remember{mutableStateOf("عامل")};var error by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
        Text("يوميات",style=MaterialTheme.typography.displaySmall);Text("إدارة أيام العمل والسلف — بدون إنترنت");Spacer(Modifier.height(22.dp))
        OutlinedTextField(name,{name=it},Modifier.fillMaxWidth(),label={Text(if(register)"الاسم" else "اسم المستخدم")})
        Spacer(Modifier.height(9.dp));OutlinedTextField(pass,{pass=it},Modifier.fillMaxWidth(),label={Text("كلمة المرور")},visualTransformation=PasswordVisualTransformation())
        if(register){Spacer(Modifier.height(9.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(role=="عامل",{role="عامل"},{Text("عامل")});FilterChip(role=="صاحب العمل",{role="صاحب العمل"},{Text("صاحب العمل")})};if(role=="عامل"){Spacer(Modifier.height(9.dp));OutlinedTextField(wage,{wage=it.filter(Char::isDigit)},Modifier.fillMaxWidth(),label={Text("أجر اليوم بالريال")})}}
        Spacer(Modifier.height(15.dp));Button({
            if(name.isBlank()||pass.isBlank()){error="أدخل البيانات كاملة";return@Button}
            if(register){val u=User("u_"+System.currentTimeMillis(),name.trim(),pass,role,wage.toLongOrNull()?:0);if(store.users().any{it.name.equals(u.name,true)})error="اسم المستخدم موجود" else {store.addUser(u);onLogin(u)}}
            else {val u=store.users().firstOrNull{it.name==name.trim()&&it.password==pass};if(u==null)error="بيانات الدخول غير صحيحة" else onLogin(u)}
        },Modifier.fillMaxWidth().height(52.dp)){Text(if(register)"إنشاء الحساب" else "دخول")}
        Spacer(Modifier.height(8.dp));TextButton({register=!register;error=""}){Text(if(register)"لدي حساب بالفعل" else "إنشاء حساب جديد")};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(15.dp));Text("تعمل البيانات محليًا ولا تحتاج إلى اتصال بالإنترنت",style=MaterialTheme.typography.bodySmall)
    }
}

@Composable fun MainApp(store:LocalStore,user:User,logout:()->Unit,refresh:()->Unit,tick:Int){
    var screen by remember{mutableStateOf("home")};var selected by remember{mutableStateOf(user.id)};var showAddWorker by remember{mutableStateOf(false)}
    val all=store.users();val workers=all.filter{it.role=="عامل"};if(user.role=="عامل")selected=user.id
    val records=store.records().filter{it.workerId==selected};val worker=workers.firstOrNull{it.id==selected}
    Scaffold(topBar={TopAppBar(title={Text("يوميات — ${user.name}")},actions={TextButton(logout){Text("خروج")}})},bottomBar={NavigationBar{NavigationBarItem(screen=="home",{screen="home"},{Text("الرئيسية")},icon={});NavigationBarItem(screen=="add",{screen="add"},{Text("تسجيل")},icon={});NavigationBarItem(screen=="log",{screen="log"},{Text("السجل")},icon={})}}){p->
        if(showAddWorker){AddWorker(store,{showAddWorker=false;refresh()},{showAddWorker=false})}
        else when(screen){"add"->AddDay(Modifier.padding(p),store,selected,{refresh();screen="log"});"log"->LogScreen(Modifier.padding(p),records);else->Home(Modifier.padding(p),user,workers,selected,{selected=it},records,worker?.wage?:0,{screen="add"},{showAddWorker=true})}
    }
}

@Composable fun Home(modifier:Modifier,user:User,workers:List<User>,selected:String,onWorker:(String)->Unit,records:List<WorkDay>,wage:Long,onAdd:()->Unit,onAddWorker:()->Unit){
    val worked=records.count{it.status=="اشتغل"};val stopped=records.count{it.status=="وقف"};val withdrawn=records.sumOf{it.amount};val earned=worked*wage;val remaining=earned-withdrawn
    Column(modifier.fillMaxSize().padding(18.dp)){Text("الملخص",style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(10.dp))
        if(user.role=="صاحب العمل"){Text("العمال",style=MaterialTheme.typography.titleMedium);Spacer(Modifier.height(5.dp));LazyColumn(Modifier.heightIn(max=110.dp)){items(workers){w->FilterChip(selected==w.id,{onWorker(w.id)},label={Text("${w.name} — ${w.wage} ريال/يوم")},modifier=Modifier.padding(bottom=5.dp))}};Button(onAddWorker,Modifier.fillMaxWidth()){Text("＋ إضافة عامل")};Spacer(Modifier.height(10.dp))}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){Stat("أيام العمل",worked.toString(),Modifier.weight(1f));Stat("التوقف",stopped.toString(),Modifier.weight(1f))};Spacer(Modifier.height(7.dp));Stat("المستحق",earned.toString()+" ريال",Modifier.fillMaxWidth());Spacer(Modifier.height(7.dp));Stat("السلف",withdrawn.toString()+" ريال",Modifier.fillMaxWidth());Spacer(Modifier.height(7.dp));Stat("المتبقي",remaining.toString()+" ريال",Modifier.fillMaxWidth());Spacer(Modifier.height(18.dp));Button(onAdd,Modifier.fillMaxWidth().height(52.dp)){Text("＋ تسجيل يوم جديد")}
    }
}
@Composable fun Stat(t:String,v:String,m:Modifier){Card(m){Column(Modifier.padding(12.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(t);Text(v,style=MaterialTheme.typography.titleLarge)}}}

@Composable fun AddWorker(store:LocalStore,onDone:()->Unit,onCancel:()->Unit){var name by remember{mutableStateOf("")};var pass by remember{mutableStateOf("")};var wage by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(20.dp)){Text("إضافة عامل",style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(12.dp));OutlinedTextField(name,{name=it},Modifier.fillMaxWidth(),label={Text("اسم العامل")});Spacer(Modifier.height(9.dp));OutlinedTextField(pass,{pass=it},Modifier.fillMaxWidth(),label={Text("كلمة مرور العامل")},visualTransformation=PasswordVisualTransformation());Spacer(Modifier.height(9.dp));OutlinedTextField(wage,{wage=it.filter(Char::isDigit)},Modifier.fillMaxWidth(),label={Text("أجر اليوم")});Spacer(Modifier.height(15.dp));Button({if(name.isBlank()||pass.isBlank()){error="أدخل الاسم وكلمة المرور"}else{store.addUser(User("u_"+System.currentTimeMillis(),name.trim(),pass,"عامل",wage.toLongOrNull()?:0));onDone()}},Modifier.fillMaxWidth()){Text("حفظ العامل")};TextButton(onCancel){Text("إلغاء")};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}}

@Composable fun AddDay(modifier:Modifier,store:LocalStore,workerId:String,onSaved:()->Unit){var status by remember{mutableStateOf("اشتغل")};var amount by remember{mutableStateOf("")};var notes by remember{mutableStateOf("")};val now=LocalDateTime.now();val date=now.toLocalDate();val h=HijrahDate.from(date);val greg=date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));val hij="${h.dayOfMonth}/${h.monthValue}/${h.year}";val weekday=date.dayOfWeek.getDisplayName(TextStyle.FULL,Locale("ar"));val time=now.format(DateTimeFormatter.ofPattern("hh:mm a"));Column(modifier.fillMaxSize().padding(20.dp)){Text("تسجيل يوم",style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(10.dp));Text("الميلادي: $greg");Text("الهجري: $hij");Text("اليوم: $weekday");Text("الوقت: $time");Spacer(Modifier.height(12.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(status=="اشتغل",{status="اشتغل"},{Text("اشتغل")});FilterChip(status=="وقف",{status="وقف"},{Text("وقف")})};Spacer(Modifier.height(9.dp));OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},Modifier.fillMaxWidth(),label={Text("السلفة / المبلغ المستلم")});Spacer(Modifier.height(9.dp));OutlinedTextField(notes,{notes=it},Modifier.fillMaxWidth(),label={Text("ملاحظات")});Spacer(Modifier.height(16.dp));Button({store.addRecord(WorkDay("r_"+System.currentTimeMillis(),workerId,greg,hij,weekday,time,status,amount.toLongOrNull()?:0,notes));onSaved()},Modifier.fillMaxWidth().height(52.dp)){Text("حفظ")}}}

@Composable fun LogScreen(modifier:Modifier,records:List<WorkDay>){Column(modifier.fillMaxSize().padding(18.dp)){Text("السجل",style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(8.dp));if(records.isEmpty())Text("لا توجد تسجيلات بعد.");LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp)){items(records){r->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text("${r.status} — ${r.gregorian}",style=MaterialTheme.typography.titleMedium);Text("هجري: ${r.hijri}");Text("${r.weekday} — ${r.time}");Text("السلفة: ${r.amount} ريال");if(r.notes.isNotBlank())Text("ملاحظات: ${r.notes}")}}}}}}
